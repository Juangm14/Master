enum Palo : String {
    case bastos = "bastos"
    case copas = "copas"
    case espadas = "espadas"
    case oros = "oros"
}
